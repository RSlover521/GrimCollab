package grim.MAIN;

public class Grim {
	public static void main (String[] args) {
		String a = "Lecede";
		for (int i = 0; i < 10; i++ ) {
			System.out.println(a);
		}
		myFunc(100);
	}
	public static void myFunc(int n){
		for (int m = 0; m <= n; m++) {
			if (m % 2 == 0) {
				System.out.println(m);
			}
			
		}
	}
}
